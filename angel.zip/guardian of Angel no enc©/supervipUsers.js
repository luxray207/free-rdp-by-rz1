const supervipUsers = [];

module.exports = supervipUsers;